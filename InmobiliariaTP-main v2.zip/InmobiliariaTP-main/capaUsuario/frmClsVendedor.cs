﻿using System.Windows.Forms;

namespace capaUsuario
{
    public partial class frmClsVendedor : Form
    {
        public frmClsVendedor()
        {
            InitializeComponent();
        }
    }
}
